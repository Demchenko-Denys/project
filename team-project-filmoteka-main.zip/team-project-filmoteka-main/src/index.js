import './sass/main.scss';


import './js/header.js';
// Eugen(modal)
import './js/modalCard';
import './js/localStorage';

//Arthur Kutusenko (input + movies gallery)
import './js/input.js';

//Sanatar Anastasiia
import './js/footer-modal.js';
import './js/change-theme.js';

//Anton Tymchenko
import './js/library.js';



